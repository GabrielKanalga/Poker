﻿namespace Poker
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.H2 = new System.Windows.Forms.PictureBox();
            this.H1 = new System.Windows.Forms.PictureBox();
            this.H8 = new System.Windows.Forms.PictureBox();
            this.H9 = new System.Windows.Forms.PictureBox();
            this.H5 = new System.Windows.Forms.PictureBox();
            this.H7 = new System.Windows.Forms.PictureBox();
            this.H6 = new System.Windows.Forms.PictureBox();
            this.H4 = new System.Windows.Forms.PictureBox();
            this.H3 = new System.Windows.Forms.PictureBox();
            this.werter = new System.Windows.Forms.NumericUpDown();
            this.erhohe = new System.Windows.Forms.Button();
            this.check = new System.Windows.Forms.Button();
            this.gth_txt = new System.Windows.Forms.Label();
            this.pot_txt = new System.Windows.Forms.Label();
            this.gegner_gth = new System.Windows.Forms.Label();
            this.outt = new System.Windows.Forms.Button();
            this.Mitkommen = new System.Windows.Forms.Button();
            this.round_txt = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.gegnerface = new System.Windows.Forms.PictureBox();
            this.Stimmung = new System.Windows.Forms.Label();
            this.Regeln_btn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.H2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.H1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.H8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.H9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.H5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.H7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.H6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.H4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.H3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.werter)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gegnerface)).BeginInit();
            this.SuspendLayout();
            // 
            // H2
            // 
            this.H2.Image = global::Poker.Properties.Resources.Back;
            this.H2.Location = new System.Drawing.Point(590, 426);
            this.H2.Name = "H2";
            this.H2.Size = new System.Drawing.Size(91, 148);
            this.H2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.H2.TabIndex = 0;
            this.H2.TabStop = false;
            this.H2.Click += new System.EventHandler(this.UH2_Click);
            // 
            // H1
            // 
            this.H1.Image = global::Poker.Properties.Resources.Back;
            this.H1.Location = new System.Drawing.Point(452, 426);
            this.H1.Name = "H1";
            this.H1.Size = new System.Drawing.Size(91, 148);
            this.H1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.H1.TabIndex = 1;
            this.H1.TabStop = false;
            this.H1.Click += new System.EventHandler(this.UH1_Click);
            // 
            // H8
            // 
            this.H8.Image = global::Poker.Properties.Resources.Back;
            this.H8.Location = new System.Drawing.Point(475, 12);
            this.H8.Name = "H8";
            this.H8.Size = new System.Drawing.Size(91, 148);
            this.H8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.H8.TabIndex = 2;
            this.H8.TabStop = false;
            this.H8.Click += new System.EventHandler(this.H8_Click);
            // 
            // H9
            // 
            this.H9.Image = global::Poker.Properties.Resources.Back;
            this.H9.Location = new System.Drawing.Point(590, 12);
            this.H9.Name = "H9";
            this.H9.Size = new System.Drawing.Size(91, 148);
            this.H9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.H9.TabIndex = 3;
            this.H9.TabStop = false;
            // 
            // H5
            // 
            this.H5.Image = global::Poker.Properties.Resources.Back;
            this.H5.Location = new System.Drawing.Point(573, 224);
            this.H5.Name = "H5";
            this.H5.Size = new System.Drawing.Size(91, 148);
            this.H5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.H5.TabIndex = 4;
            this.H5.TabStop = false;
            // 
            // H7
            // 
            this.H7.Image = global::Poker.Properties.Resources.Back;
            this.H7.Location = new System.Drawing.Point(815, 224);
            this.H7.Name = "H7";
            this.H7.Size = new System.Drawing.Size(91, 148);
            this.H7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.H7.TabIndex = 5;
            this.H7.TabStop = false;
            // 
            // H6
            // 
            this.H6.Image = global::Poker.Properties.Resources.Back;
            this.H6.Location = new System.Drawing.Point(690, 224);
            this.H6.Name = "H6";
            this.H6.Size = new System.Drawing.Size(91, 148);
            this.H6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.H6.TabIndex = 6;
            this.H6.TabStop = false;
            this.H6.Click += new System.EventHandler(this.M4_Click);
            // 
            // H4
            // 
            this.H4.Image = global::Poker.Properties.Resources.Back;
            this.H4.Location = new System.Drawing.Point(443, 224);
            this.H4.Name = "H4";
            this.H4.Size = new System.Drawing.Size(91, 148);
            this.H4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.H4.TabIndex = 7;
            this.H4.TabStop = false;
            // 
            // H3
            // 
            this.H3.Image = global::Poker.Properties.Resources.Back;
            this.H3.Location = new System.Drawing.Point(318, 224);
            this.H3.Name = "H3";
            this.H3.Size = new System.Drawing.Size(91, 148);
            this.H3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.H3.TabIndex = 8;
            this.H3.TabStop = false;
            // 
            // werter
            // 
            this.werter.Increment = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.werter.Location = new System.Drawing.Point(815, 476);
            this.werter.Maximum = new decimal(new int[] {
            2000,
            0,
            0,
            0});
            this.werter.Name = "werter";
            this.werter.Size = new System.Drawing.Size(180, 31);
            this.werter.TabIndex = 9;
            // 
            // erhohe
            // 
            this.erhohe.Location = new System.Drawing.Point(1017, 476);
            this.erhohe.Name = "erhohe";
            this.erhohe.Size = new System.Drawing.Size(112, 34);
            this.erhohe.TabIndex = 10;
            this.erhohe.Text = "Erhöhen";
            this.erhohe.UseVisualStyleBackColor = true;
            this.erhohe.Click += new System.EventHandler(this.erhohe_Click);
            // 
            // check
            // 
            this.check.Location = new System.Drawing.Point(1017, 516);
            this.check.Name = "check";
            this.check.Size = new System.Drawing.Size(112, 34);
            this.check.TabIndex = 11;
            this.check.Text = "Checken";
            this.check.UseVisualStyleBackColor = true;
            this.check.Click += new System.EventHandler(this.check_Click);
            // 
            // gth_txt
            // 
            this.gth_txt.AutoSize = true;
            this.gth_txt.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.gth_txt.Location = new System.Drawing.Point(1011, 426);
            this.gth_txt.Name = "gth_txt";
            this.gth_txt.Size = new System.Drawing.Size(0, 25);
            this.gth_txt.TabIndex = 12;
            // 
            // pot_txt
            // 
            this.pot_txt.AutoSize = true;
            this.pot_txt.Location = new System.Drawing.Point(22, 267);
            this.pot_txt.Name = "pot_txt";
            this.pot_txt.Size = new System.Drawing.Size(0, 25);
            this.pot_txt.TabIndex = 13;
            // 
            // gegner_gth
            // 
            this.gegner_gth.AutoSize = true;
            this.gegner_gth.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.gegner_gth.Location = new System.Drawing.Point(208, 21);
            this.gegner_gth.Name = "gegner_gth";
            this.gegner_gth.Size = new System.Drawing.Size(59, 25);
            this.gegner_gth.TabIndex = 14;
            this.gegner_gth.Text = "label1";
            this.gegner_gth.Click += new System.EventHandler(this.label1_Click);
            // 
            // outt
            // 
            this.outt.Location = new System.Drawing.Point(1017, 556);
            this.outt.Name = "outt";
            this.outt.Size = new System.Drawing.Size(112, 36);
            this.outt.TabIndex = 15;
            this.outt.Text = "Out";
            this.outt.UseVisualStyleBackColor = true;
            this.outt.Click += new System.EventHandler(this.outt_Click);
            // 
            // Mitkommen
            // 
            this.Mitkommen.Location = new System.Drawing.Point(830, 556);
            this.Mitkommen.Name = "Mitkommen";
            this.Mitkommen.Size = new System.Drawing.Size(145, 34);
            this.Mitkommen.TabIndex = 16;
            this.Mitkommen.Text = "Mitkommen";
            this.Mitkommen.UseVisualStyleBackColor = true;
            this.Mitkommen.Click += new System.EventHandler(this.Mitkommen_Click);
            // 
            // round_txt
            // 
            this.round_txt.AutoSize = true;
            this.round_txt.Location = new System.Drawing.Point(949, 50);
            this.round_txt.Name = "round_txt";
            this.round_txt.Size = new System.Drawing.Size(82, 25);
            this.round_txt.TabIndex = 17;
            this.round_txt.Text = "Runde: 1";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Poker.Properties.Resources.hintergrund1;
            this.pictureBox1.Location = new System.Drawing.Point(-1, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1197, 619);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 18;
            this.pictureBox1.TabStop = false;
            // 
            // gegnerface
            // 
            this.gegnerface.Image = global::Poker.Properties.Resources.Gegnerhappy;
            this.gegnerface.Location = new System.Drawing.Point(726, 12);
            this.gegnerface.Name = "gegnerface";
            this.gegnerface.Size = new System.Drawing.Size(150, 101);
            this.gegnerface.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gegnerface.TabIndex = 19;
            this.gegnerface.TabStop = false;
            // 
            // Stimmung
            // 
            this.Stimmung.AutoSize = true;
            this.Stimmung.Location = new System.Drawing.Point(726, 116);
            this.Stimmung.Name = "Stimmung";
            this.Stimmung.Size = new System.Drawing.Size(139, 25);
            this.Stimmung.TabIndex = 20;
            this.Stimmung.Text = "Mood: Glücklich";
            // 
            // Regeln_btn
            // 
            this.Regeln_btn.BackColor = System.Drawing.SystemColors.Info;
            this.Regeln_btn.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.Regeln_btn.Location = new System.Drawing.Point(-1, 3);
            this.Regeln_btn.Name = "Regeln_btn";
            this.Regeln_btn.Size = new System.Drawing.Size(112, 34);
            this.Regeln_btn.TabIndex = 21;
            this.Regeln_btn.Text = "Regeln";
            this.Regeln_btn.UseVisualStyleBackColor = false;
            this.Regeln_btn.Click += new System.EventHandler(this.Regeln_btn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1195, 619);
            this.Controls.Add(this.Regeln_btn);
            this.Controls.Add(this.Stimmung);
            this.Controls.Add(this.gegnerface);
            this.Controls.Add(this.round_txt);
            this.Controls.Add(this.Mitkommen);
            this.Controls.Add(this.outt);
            this.Controls.Add(this.gegner_gth);
            this.Controls.Add(this.pot_txt);
            this.Controls.Add(this.gth_txt);
            this.Controls.Add(this.check);
            this.Controls.Add(this.erhohe);
            this.Controls.Add(this.werter);
            this.Controls.Add(this.H3);
            this.Controls.Add(this.H4);
            this.Controls.Add(this.H6);
            this.Controls.Add(this.H7);
            this.Controls.Add(this.H5);
            this.Controls.Add(this.H9);
            this.Controls.Add(this.H8);
            this.Controls.Add(this.H1);
            this.Controls.Add(this.H2);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.H2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.H1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.H8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.H9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.H5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.H7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.H6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.H4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.H3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.werter)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gegnerface)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PictureBox H2;
        private PictureBox H1;
        private PictureBox H8;
        private PictureBox H9;
        private PictureBox H5;
        private PictureBox H7;
        private PictureBox H6;
        private PictureBox H4;
        private PictureBox H3;
        private NumericUpDown werter;
        private Button erhohe;
        private Button check;
        private Label gth_txt;
        private Label pot_txt;
        private Label gegner_gth;
        private Button outt;
        private Button Mitkommen;
        private Label round_txt;
        private PictureBox pictureBox1;
        private PictureBox gegnerface;
        private Label Stimmung;
        private Button Regeln_btn;
    }
}